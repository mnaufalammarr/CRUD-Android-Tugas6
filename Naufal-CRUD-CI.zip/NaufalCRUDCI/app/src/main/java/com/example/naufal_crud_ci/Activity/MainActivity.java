package com.example.naufal_crud_ci.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.naufal_crud_ci.Adapter.FoodAdapter;
import com.example.naufal_crud_ci.Model.Food;
import com.example.naufal_crud_ci.Model.GetFood;
import com.example.naufal_crud_ci.R;
import com.example.naufal_crud_ci.Rest.ApiClient;
import com.example.naufal_crud_ci.Rest.ApiInterface;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.security.Policy;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ApiInterface mApiInterface;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    public static MainActivity ma;
    private FloatingActionButton fabAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = (RecyclerView) findViewById(R.id.rv_food);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        ma=this;
        refresh();

        fabAdd = findViewById(R.id.fab_add);
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, InsertActivity.class));
            }
        });
    }

    public void refresh() {
        Call<GetFood> FoodCall = mApiInterface.getFood();
        FoodCall.enqueue(new Callback<GetFood>() {
            @Override
            public void onResponse(Call<GetFood> call, Response<GetFood>
                    response) {
                List<Food> FoodList = response.body().getListDataFood();
                Log.d("Retrofit Get", "Jumlah data Food: " +
                        String.valueOf(FoodList.size()));
                mAdapter = new FoodAdapter(FoodList);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<GetFood> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }

}